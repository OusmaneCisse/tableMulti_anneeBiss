#
Le package tableMulti_anneeBiss contient deux modules "annee_bissextile" & "table_multiplication"
========================================================

le module annee_bissextile permet de verifier à partir d'une année entrer au clavier si elle est bissextile ou non.
========================================================

Le module table_multiplication permet d'afficher la table de multiplication en fonction d'un nombre enter au clavier.

Vous pouvez l'installer avec pip:

    pip install tableMulti_anneeBiss

Exemple d'usage:

    >>> from tableMulti_anneeBiss import annee_bissextile
    >>> annee_bissextile()

Ce code est sous licence WTFPL.